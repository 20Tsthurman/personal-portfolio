"""This file is used to store configuration variables, such as the Claude API key.
By keeping the API key in a separate configuration file, you can easily manage and update it without modifying the main application code.
You can import the API key from this file into chatbot.py to use it when initializing the Anthropic client."""


API_KEY = "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"